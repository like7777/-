var header,sidenav;
header = '<!-- Logo -->\
			<a href="javascript:void(0)" class="logo">\
				<!-- mini logo for sidebar mini 50x50 pixels -->\
				<span class="logo-mini">后台</span>\
				<!-- logo for regular state and mobile devices -->\
				<span class="logo-lg">供应商后台</span>\
			</a>\
			<!-- Header Navbar: style can be found in header.less -->\
			<nav class="navbar navbar-static-top">\
				<!-- Sidebar toggle button-->\
				<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">\
					<span class="sr-only">Toggle navigation</span>\
				</a>\
				<div class="navbar-custom-menu">\
					<ul class="nav navbar-nav">\
						<!-- User Account: style can be found in dropdown.less -->\
						<li class="dropdown user user-menu">\
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">\
								<img src="../dist/img/user2-160x160.jpg" class="user-image" alt="User Image">\
								<span class="hidden-xs manager-name">'+localStorage.getItem('supplier_managerName')+'</span>\
							</a>\
							<ul class="dropdown-menu">\
								<!-- User image -->\
								<li class="user-header">\
									<img src="../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">\
									<p class="manager-name">'+localStorage.getItem('supplier_managerName')+'</p>\
								</li>\
								<!-- Menu Footer-->\
								<li class="user-footer">\
									<div class="pull-right">\
										<a href="#" class="btn btn-default btn-flat" onclick="exit()">退出登录</a>\
									</div>\
								</li>\
							</ul>\
						</li>\
					</ul>\
				</div>\
			</nav>'

//退出
function exit(){
//	$.ajax({
//		type:"post",
//		url:url+'admin_sign_out',
//		data:{
//			token:localStorage.getItem('loginToken')
//		},
//		async:true,
//		success:function(res){
//			var resJSON = eval('('+res+')')
//			reLogin(resJSON.status)
//			if(resJSON.status==1){
//				localStorage.clear()
//				location.href = 'login.html'
//			}else{
//				alert(resJSON.error)
//			}
//		},
//		error:function(res){
//			error(res)
//		}
//	});
	localStorage.clear()
	location.href = 'login.html'
}

$(".main-header").html(header)
// var titlePart = '<section class="content-header"> <h1> 天斧商城 <small>供货商后台系统</small> </h1> </section>'
// $(".content-wrapper").prepend(titlePart)
sidenav = '<section class="sidebar"><ul class="sidebar-menu" data-widget="tree">'//<li><a href="index.html"><span>首页</span></a></li>
// var icon = {
// 	'首页':'fa-home',
// 	'用户管理':'fa-group',
// 	'订单管理':'fa-legal',
// 	'财务管理':'fa-folder-open',
// 	'系统管理':'fa-gear',
// 	'账户管理':'fa-user',
// 	'数据统计':'fa-bar-chart',
// 	'审核管理':'fa-calendar-check-o',
// 	'抢单规则设置':'fa-gear',
// 	'权限管理':'fa-gear',
// 	'文章管理':'fa-gear',
// 	'财务设置':'fa-folder-open',
// 	'App管理':'fa-gear'
// }

function navShow(obj,num){

	var key11    =[
		
		
		{
			"name" : "订单管理",	
			'data' : [
				{
					'names':'订单列表',
					"url" : "order-list.html"	
				},
			]					
		},
		{           
			"name" : "商品管理",  
			'data' : [
				{
					'names':'商品列表',
					"url" : "commodity-list.html"	
				}
			]
		},
		
						
	]
	
	/*for(var x = 0 ;x < key10.length ;x++){
		console.log(key10[x].data != '')
		console.log(key10[x].data[0].names)
		if(key10[x].data != ''){
			console.log(key10[x].data[0].names)
			console.log(key10[x].data.names)
			sidenav += '<li class="treeview">\<a href="#">\
			<span>'+key10[x].name+'</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>\
			</a>\
			<ul class="treeview-menu">\
			'
			sidenav += '</ul></li>'
	}
}*/

$.each(key11,function(index,item){
	sidenav += '<li class="treeview"><a href="#"><span>'+item.name+'</span>\
			<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>\
			</a>\
			<ul class="treeview-menu">\
			'
			$.each(item.data,function(indexs,items){
				//console.log(items.names)
				sidenav+='<li class=""><a href="'+items.url+'" >'+items.names+'</a><ul class="treeview-menu" id="ulhas">'
				$.each(items.data,function(indexss,itemss){
					console.log(itemss)
					sidenav+= '<li class="li"><a href="#"><i class="fa fa-circle-o"></i>'+itemss.names+'</a></li>'
				})
				sidenav+='</ul></li>'
			})
	sidenav += '</ul></li>'
})

	


	$('.treeview-menu').children(":first").click(function(){
		console.log(1)
	})
	//num=1表示加载一级目录
	// $.each(obj, function(key,value) {
	// 	console.log(value)
	// 	switch(Array.isArray(value)){
			
	// 		case false:
	// 			var iconStyle = ''
	// 			if(num==1){
	// 				iconStyle = icon[key]
	// 					sidenav += '<li><a href="'+value.url+'" data-page-id="'+value.pageId+'"><i class="fa '+iconStyle+'"></i> <span>'+value.name+'</span></a></li>';								
	// 			}
	// 			//二级菜单
	// 			else{					
	// 				$.each(value,function(key1,value1){
						
	// 					switch(Array.isArray(value1)){
							
	// 						case false:
							
	// 							if(key1=='name'&&value.name!='提额设置'){
	// 									sidenav += '<li><a href="'+value.url+'" data-page-id="'+value.pageId+'"><i class="fa '+iconStyle+'"></i> <span>'+value.name+'</span></a></li>';									
	// 							}
	// 							break;
	// 						case true:
							
	// 							sidenav += '<li class="treeview">\
	// 											<a href="#">\
	// 												<i class="fa"></i>\
	// 												<span>'+key1[i]+'</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>\
	// 											</a>\
	// 											<ul class="treeview-menu">'
	// 							navShow(value1,2)
	// 							sidenav += '</ul></li>'
	// 					}
	// 				})
	// 			}
	// 			break;
	// 		case true:
	// 			var iconStyle = ''
	// 			if(num==1){
				
					
	// 			}
				
			
	// 				// console.log(key1)
	// 				// iconStyle = icon[key]		
						
					
	// 	}
	// });
}
var power;
if(localStorage.getItem('power')!=null){
	power = eval('('+localStorage.getItem('power')+')')
}
navShow(power,1)
sidenav += '</ul></section>'

//获取到上面遍历的dom
$(".main-sidebar").html(sidenav)

var localArr = location.href.split('/')
var localname = localArr[localArr.length-1].split('.html')[0]
$(".main-sidebar").find('a[href="'+localname+'.html"]').closest('li').addClass('active')
//添加选中状态
var oParent = $(".main-sidebar").find('a[href="'+localname+'.html"]');
for(;;){
  if(oParent.closest('ul').hasClass('treeview-menu')){
    oParent.closest('ul').parent().addClass('active')
    oParent = oParent.closest('ul').parent()
  }else{
    break;
  }
}
var activetitle = oParent.find('span').html()
var activetitlef = oParent.find($('.active')).find('a').html()
if(activetitle == undefined){
	var titlePart = '<section class="content-header"> <h1></h1> </section>'
}else if(activetitlef == undefined){
	var titlePart = '<section class="content-header"> <h1>'+activetitle+' </h1> </section>'
}else {
	var titlePart = '<section class="content-header"> <h1>'+activetitle+'<small>'+activetitlef+'</small> </h1> </section>'
}
$(".content-wrapper").prepend(titlePart)



var localArr = location.href.split('/')
var localname = localArr[localArr.length-1].split('.html')[0]
$(".main-sidebar").find('a[href="'+localname+'.html"]').closest('li').addClass('active')
//添加选中状态
var oParent = $(".main-sidebar").find('a[href="'+localname+'.html"]');
for(;;){
	if(oParent.closest('ul').hasClass('treeview-menu')){
		oParent.closest('ul').parent().addClass('active')
		oParent = oParent.closest('ul').parent()
	}else{
		break;
	}
}
//登录过期返回登录页
function reLogin(status){
	if(status == 501) {
		localStorage.clear()
		location.href = 'login.html'
	}
}
//接口错误反馈
function error(res){
	alert('接口报错')
	console.log(res)
	$("#loading").hide()
}
//表格搜索
$("#search-btn").click(function(){
	table.ajax.reload()
})
//屏蔽datatables警告弹框	
if($("#dataTable").length>0){
	$.fn.dataTable.ext.errMode = 'none';
}
//全选或全不选
$('input[type="checkbox"][name="all"]').click(function(){
	if($(this).prop('checked')==true){
		$('input[type="checkbox"][name="simple"]').prop('checked',true)
	}else{
		$('input[type="checkbox"][name="simple"]').prop('checked',false)
	}
})

//表格编辑
$('table').on('click','.fa-pencil',function(){
	$(this).prev().prop('disabled',false)
	$(this).prev().focus()
})
//新增清空
$('[data-target="#modal-add"]').click(function(){
	$("#modal-add").find('input[type=text]').val('')
	$("#modal-add").find('input[type=file]').val('')
	$("#modal-add").find('input[type=hidden]').val('')
	$("#modal-add").find('input[name=token]').val(localStorage.getItem('login_token'))
	$("#modal-add").find('input[name=isSystemAccount]').val(2)
	$("#modal-add").find('input[name=managerId]').val(localStorage.getItem('managerId'))
	$("#modal-add").find('textarea').val('')
	$("#addForm .ke-edit-iframe").contents().find("body").html('')
	$("#modal-add").find('img').attr('src','dist/img/addImg.png')
})

//预览上传图片
//$('[data-opera="imgUpload"]').change(function(){
//	var docObj = $(this)[0];
//	if(docObj.files && docObj.files[0]) {
//		$('[data-opera="imgPriview"]').attr('src', window.URL.createObjectURL(docObj.files[0]));
//	}
//})
//初始时间设置
$("#starttime").datepicker({
	autoclose:true,
	format:'yyyy-mm-dd'
})
//结束时间设置
$("#endtime").datepicker({
	autoclose:true,
	format:'yyyy-mm-dd'
})
//时间戳转时间
function timestampToTime(timestamp,isNo) {
	var date = new Date(timestamp * 1000); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
	Y = date.getFullYear() + '-';
	M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
	D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
	h = (date.getHours() < 10 ? '0' + (date.getHours()) : date.getHours()) + ':';
	m = (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes()) + ':';
	s = (date.getSeconds() < 10 ? '0' + (date.getSeconds()) : date.getSeconds());
	if(isNo){
		return Y + M + D;
	}else{
		return Y + M + D + h + m + s;
	}
	
}
//获取七牛token
function getQiniuToken(){
	var token = ''
	$.ajax({
		type:"post",
		url:url+"system/getQiniuToken",
		async:false,
		contentType: 'application/json',
		data:JSON.stringify({token:localStorage.getItem('login_token')}),
		dataType:'json',
		success:function(res){
			if(res.returnCode==200){
				token = res.data
			}
		},
		error:function(){
			error()
		}
	});
	return token
}
//上传图片
function updata_pic(pic, token ,id) { //.files;
	var putExtra = {
		fname: "",
		params: {},
		mimeType: null
	};
	var config = {
		useCdnDomain: true,
		region: qiniu.region.z2, //华南
	};
	var date_ = Date.parse(new Date());
	var observer = {
		next(res) {},
		error(err) {
			alert(JSON.stringify(err))
			alert("照片上传失败！")
		},
		complete(res) {
			//res.key为图片链接
			$("#"+id).prev().attr('src',imgUrl+res.key)
			$("#"+id).next().val(res.key)
		},
	};
	var observable = qiniu.upload(pic, date_, token, putExtra, config)
	var subscription = observable.subscribe(observer)
}
//添加图片
$("#add-picUrl").change(function(){
	var token = getQiniuToken()
	var reads = new FileReader()
	var f = document.getElementById('add-picUrl')
	var pic = f.files[0]
	reads.readAsDataURL(pic)
	reads.onload = function(){
		updata_pic(pic,token,'add-picUrl')
	}
})
//添加图片-编辑
$("#change-picUrl").change(function(){
	var token = getQiniuToken()
	var reads = new FileReader()
	var f = document.getElementById('change-picUrl')
	var pic = f.files[0]
	reads.readAsDataURL(pic)
	reads.onload = function(){
		updata_pic(pic,token,'change-picUrl')
	}
})
//表单传输时使用
if($("[name='token']").length>0){
	$("[name='token']").val(localStorage.getItem('login_token'))
}
if($("[name='managerId']").length>0){
	$("[name='managerId']").val(localStorage.getItem('managerId'))
}
//表单数据转json字符串
function dataToJsonstring(idname){
	
//	var dataArr = data.split('&')
	var returnData = {}
//	$.each(dataArr, function(key,value) {
//		if(value.split('=')[1]!=''){
//			returnData[value.split('=')[0]] = value.split(value.split('=')[0]+'=')[1]
//		}
//	});
	var oInputText = $("#"+idname).find('input[type=text]')
	for(var i=0;i<oInputText.length;i++){
		if(oInputText.eq(i).prop('disabled')==false){
			returnData[oInputText.eq(i).attr('name')] = oInputText.eq(i).val()
		}
	}
	var oTextarea = $("#"+idname).find('textarea')
	for(var i=0;i<oTextarea.length;i++){
		if(oTextarea.eq(i).prop('disabled')==false){
			returnData[oTextarea.eq(i).attr('name')] = oTextarea.eq(i).val()
		}
		
	}
	var oInputHidden = $("#"+idname).find('input[type=hidden]')
	for(var i=0;i<oInputHidden.length;i++){
		if(oInputHidden.eq(i).prop('disabled')==false){
			returnData[oInputHidden.eq(i).attr('name')] = oInputHidden.eq(i).val()
		}
		
	}
	var oInputPass = $("#"+idname).find('input[type=password]')
	for(var i=0;i<oInputPass.length;i++){
		if(oInputPass.eq(i).prop('disabled')==false){
			returnData[oInputPass.eq(i).attr('name')] = oInputPass.eq(i).val()
		}
		
	}
	var oSelect = $("#"+idname).find('select')
	for(var i=0;i<oSelect.length;i++){
		if(oSelect.eq(i).prop('disabled')==false){
			returnData[oSelect.eq(i).attr('name')] = oSelect.eq(i).val()
		}
		
	}
	var oRadio = $("#"+idname).find('input[type=radio]:checked')
	for(var i=0;i<oRadio.length;i++){
		if(oRadio.eq(i).prop('disabled')==false){
			returnData[oRadio.eq(i).attr('name')] = oRadio.eq(i).val()
		}
		
	}
	var oCheck = $("#"+idname).find('input[type=checkbox]:checked')
	for(var i=0;i<oCheck.length;i++){
		if(oCheck.eq(i).prop('disabled')==false){
			returnData[oCheck.eq(i).attr('name')] = oCheck.eq(i).val()
		}
		
	}
	return JSON.stringify(returnData);
}
//新增
$("#add-sure").click(function(){
	var inter = $(this).attr('data-interface')
	$.ajax({
		type:"post",
		url:url+inter,
		contentType:'application/json;charset=utf-8',
		async:true,
		data:dataToJsonstring('addForm'),
		success:function(res){
			reLogin(res.returnCode)
			if(res.returnCode==200){
				$("#modal-add").modal('hide')
				table.ajax.reload()
				alert("新增成功")
			}else{
				alert(res.msg)
			}
		},
		error:function(res){
			error(res)
		}
	});
})
//编辑
function change(x){
	var data = JSON.parse($(x).attr('data-data'))
	$.each(data, function(key,value) {
		if(key!='token'){
			$("#changeForm").find('[name="'+key+'"]').val(value)
		}
		if(key=='picUrl'||key=='pic_url'){
			$("#changeForm").find('[data-name="'+key+'"]').attr('src',imgUrl+value)
		}
	});
	$("#changeForm").find('input[name=token]').val(localStorage.getItem('login_token'))
	$("#changeForm").find('input[name=managerId]').val(localStorage.getItem('managerId'))
	$("#modal-change").modal('show')
}
$("#change-sure").click(function(){
	var inter = $(this).attr('data-interface')
	$.ajax({
		type:"post",
		url:url+inter,
		contentType:'application/json;charset=utf-8',
		async:true,
		data:dataToJsonstring('changeForm'),
		success:function(res){
			reLogin(res.returnCode)
			if(res.returnCode==200){
				$("#modal-change").modal('hide')
				table.ajax.reload()
				alert("修改成功")
			}else{
				alert(res.msg)
			}
		},
		error:function(res){
			error(res)
		}
	});
})
//删除
function del(idName,id){
	$("#del-sure").attr('data-idName',idName)
	$("#del-sure").attr('data-id',id)
	$("#modal-del").modal('show')
}
$("#del-sure").click(function(){
	var inter = $(this).attr('data-interface')
	var data = {
		token:localStorage.getItem('login_token')
	}
	data[$(this).attr('data-idName')] = $(this).attr('data-id')
	$.ajax({
		type:"post",
		url:url+inter,
		contentType:'application/json',
		async:false,
		data:JSON.stringify(data),
		success:function(res){
			reLogin(res.returnCode)
			if(res.returnCode==200){
				$("#modal-del").modal('hide')
				table.ajax.reload()
				alert("删除成功")
			}else{
				alert(res.msg)
			}
		},
		error:function(res){
			error(res)
		}
	});
})
$(".question").hover(function(){
	if($(this).children().hasClass('on')){
		$(this).children().removeClass('on')
	}else{
		$(this).children().addClass('on')
	}
})

//上传图片或视频
function uploadFile(file){
	var fileUrl = ''
	var data = new FormData();
	data.append('file',file)
	$.ajax({
		type:"post",
		url:url+"app/user/uploadFile",
		async:false,
		contentType:false,
		processData:false,
		cache: false,
		data:data,
		dataType:'json',
		success:function(res){
			if(res.returnCode==200){
				fileUrl = res.data
			}else{
				alert(res.msg);
			}
		},
		error:function(){
			error()
		}
	});
	return fileUrl;
}
//图片上传
$('[data-opera="imgUpload"]').change(function(){
	var fileLink = uploadFile($(this)[0].files[0]);
	if(fileLink){
		$(this).prev().attr('src',fileLink);
		$(this).next().val(fileLink);
	}
})

$("table").on("click",'img',function(){
	var img = $(this).attr("src")
	console.log(111111111111)
	if($("#popupImg").length == 0){
		console.log(222)
		$('body').append("<div class='popup'id='popupImg'><img src='"+img+"'></div>")
	}else{
		console.log(333)
		$("#popupImg img").attr('src',img);
		$("#popupImg").show();
		
	}
})
$('body').on('click','#popupImg',function(){
	$(this).hide();
})


//主图七牛云
function ztupdata_pic(pic, token , dom) { //.files;
	var putExtra = {
		fname: "",
		params: {},
		mimeType: null
	};
	var config = {
		useCdnDomain: true,
		region: qiniu.region.z2, //华南
	};
	var date_ = Date.parse(new Date());
	var observer = {
		next(res) {},
		error(err) {
			alert(JSON.stringify(err))
			alert("照片上传失败！")
		},
		complete(res) {
			
			dom.siblings("label").find('img').attr('src',picUrl+res.key)
			console.log("上传成功了")
		},
	};
	var observable = qiniu.upload(pic, date_, token, putExtra, config)
	var subscription = observable.subscribe(observer)
}

//主图七牛云
function ztupdata_pic(pic, token , dom) { //.files;
	var putExtra = {
		fname: "",
		params: {},
		mimeType: null
	};
	var config = {
		useCdnDomain: true,
		region: qiniu.region.z2, //华南
	};
	var date_ = Date.parse(new Date());
	var observer = {
		next(res) {},
		error(err) {
			alert(JSON.stringify(err))
			alert("照片上传失败！")
		},
		complete(res) {
			dom.siblings("label").find('img').attr('src',picUrl+res.key)
			console.log("上传成功了")
		},
	};
	var observable = qiniu.upload(pic, date_, token, putExtra, config)
	var subscription = observable.subscribe(observer)
}	



//七牛云多图片上传
	function qiniuyun_pic(pic, token,fun) { //.files;
		var putExtra = {
			fname: "",
			params: {},
			mimeType: null
		};
		var config = {
			useCdnDomain: true,
			region: qiniu.region.z2, //华南
		};
		var date_ = Date.parse(new Date()) + pic.name;
		var observer = {
			next(res) {},
			error(err) {
				alert(JSON.stringify(err))
				alert("照片上传失败！")
			},
			complete(res) {
				// console.log(picUrl+res.key)
				// $('#changeImgDom').attr('src',picUrl+res.key)
				// console.log("上传成功了")
				fun(res)
			},
		};
		var observable = qiniu.upload(pic, date_, token, putExtra, config)
		var subscription = observable.subscribe(observer)
	}

	var onePic = $("#one-pic"),
	morePic = $("#more-pic"),
	type="",
	dom = null;

	onePic.change(function(){
		
		type = $('#one-pic').val()
		console.log(type)
		
		
	})	
		
	function fun1(){
		onePic.click()
		
	}