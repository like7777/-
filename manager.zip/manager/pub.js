//接口前缀
//var url = location.href.split('lazada_h5/')[0]
var url = 'http://cheshiuw.beydream.cn:8086/tianfu'
//域名前缀
var proName = '天斧商城';
var imgUrl = 'http://fenrun7n.uucheng.cn/'
// $("title").html('天斧商城')
//Hades token phone定义
var token = localStorage.getItem('login_token')
var phone = localStorage.getItem('account')
var qnurl = '/system/getQiniuToken'
